from django.apps import AppConfig


class ButtonsConfig(AppConfig):
    name = 'Buttons'
