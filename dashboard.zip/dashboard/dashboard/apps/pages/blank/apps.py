from django.apps import AppConfig


class BlankConfig(AppConfig):
    name = 'blank'
