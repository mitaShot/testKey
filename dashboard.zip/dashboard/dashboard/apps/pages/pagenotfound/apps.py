from django.apps import AppConfig


class PageNotFoundConfig(AppConfig):
    name = 'pagenotfound'
