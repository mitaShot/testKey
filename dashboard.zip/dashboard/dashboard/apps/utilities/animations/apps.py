from django.apps import AppConfig


class AnimationsConfig(AppConfig):
    name = 'animations'
