from django.apps import AppConfig


class BordersConfig(AppConfig):
    name = 'borders'
