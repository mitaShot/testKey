from django.apps import AppConfig


class ColorsConfig(AppConfig):
    name = 'colors'
