from django.contrib import admin

from django.urls import path

import dashboard.apps.frontend.views as views

app_name = 'main'

urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('admin/', admin.site.urls),
]
