from django.apps import AppConfig


class CountproductConfig(AppConfig):
    name = 'countProduct'
