from django.shortcuts import render, redirect
from django.views import View
from django.views import generic
from django import forms
from countProduct.app import checkCount
import json

class CountProduct(generic.TemplateView):
    def get(self, request, *args, **kwargs):
        template_name = 'countProduct/countProduct.html'
        return render(request, template_name)
    
#키워드 검색
def runCountProduct(request):
    template_name = 'countProduct/countProduct.html'
#     data = request.POST.get('search1')
    data = checkCount.getChekcProduct()
    return render(request, template_name, data)

def checkSujinPet(request):
    template_name = 'countProduct/countProduct.html'
#     data = request.POST.get('search1')
    data = checkCount.getCheckSujinPet()
    return render(request, template_name, data)


def checkBananaB2b(request):
    template_name = 'countProduct/countProduct.html'
#     data = request.POST.get('search1')
    data = checkCount.getCheckBananaB2b()
    return render(request, template_name, data)


