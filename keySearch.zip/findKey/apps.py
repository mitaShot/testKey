from django.apps import AppConfig


class FindkeyConfig(AppConfig):
    name = 'findKey'
