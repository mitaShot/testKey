from django.shortcuts import render, redirect
from django.views import View
from django.views import generic
from django import forms
from findKey.app import runSearch
import json

class FindKey(generic.TemplateView):
    def get(self, request, *args, **kwargs):
        template_name = 'findKey/index.html'
        return render(request, template_name)
    
class NameForm(forms.Form):
    yourName = forms.CharField(label="Your name", widget=forms.TextInput)

#키워드 검색
def runSearchKeyword(request):
    template_name = 'findKey/index.html'
    data = request.POST.get('search1')
    data = runSearch.getKeywords(data)
    return render(request, template_name, data)

