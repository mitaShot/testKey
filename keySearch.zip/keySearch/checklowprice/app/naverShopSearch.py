import os
import sys
import urllib.request
import json
import time
from findKey.app import signaturehelper
import xmltodict
import re
import requests
from bs4 import BeautifulSoup



def remove_tag(content):
   cleanr =re.compile('<.*?>')
   cleantext = re.sub(cleanr, '', content)
   return cleantext


def getlowprice(searchName):
    timestamp = str(round(time.time() * 1000))
    
    client_id = "eGNsR5D88XajLpoACcrN"
    client_secret = "iRx5KGT8CH"
    encText = urllib.parse.quote(searchName)
    #url = "https://openapi.naver.com/v1/search/blog?query=" + encText # json 결과
    url = "https://openapi.naver.com/v1/search/shop.xml?query=" + encText + "&display=100" # xml 결과
    #url = "https://search.shopping.naver.com/search/all.nhn?origQuery="  + encText + "&pagingIndex=1&pagingSize=80&viewType=list&sort=rel&frm=NVSHPAG&query=" + encText # xml 결과
    #request = urllib.request.Request("", url)
    request = urllib.request.Request(url)
    request.add_header("X-Naver-Client-Id",client_id)
    request.add_header("X-Naver-Client-Secret",client_secret)
    response = urllib.request.urlopen(request)
    rescode = response.getcode()
    
    shopLank = 0
    
    if(rescode==200):
        response_body = response.read()
        xmlData = response_body.decode('utf-8')

        jsonString = json.dumps(xmltodict.parse(xmlData), indent=2)
        
        jsonDict1 = json.loads(jsonString)["rss"]["channel"]
        total = jsonDict1["total"]
        
        jsonDict2 = jsonDict1["item"]
        
        i = 1
        for jsonDict in jsonDict2:
            productName = remove_tag(jsonDict["title"])
#             productLink = jsonDict["link"]
#             productImage = jsonDict["image"]
#             
#             productLprice = jsonDict["lprice"]
#             productHprice = jsonDict["hprice"]
            productMallName = jsonDict["mallName"]
#             productType = jsonDict["productType"]  #1:가격비교상품 #2:가격비교 비매칭 #3:가격비교매칭 일반상품
            
            jsonDict["title"] = productName
            
            if productMallName == "트렌드49":
                shopLank = i
                jsonDict1["trend49Price"] = jsonDict["lprice"]
                
            i = i + 1
        
        jsonDict1["title"] = total
         
        jsonDict1["link"] = shopLank
        
    else:
        print("Error Code:" + rescode)
    
    return jsonDict1

#네이버 쇼핑 사이트 검색
