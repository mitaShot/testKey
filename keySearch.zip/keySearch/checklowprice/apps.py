from django.apps import AppConfig


class ChecklowpriceConfig(AppConfig):
    name = 'checklowprice'
