from django.shortcuts import render, redirect
from django.views import View
from django.views import generic
from django import forms
from checklowprice.app import naverShopSearch
import json
from django.core.cache import cache

class Checklowprice(generic.TemplateView):
    def get(self, request, *args, **kwargs):
        template_name = 'checklowprice/checklowprice.html'
        
        cache_key = 'findKey'
        count = cache.get(cache_key, None)
        if not count:
            data = {}
        else:
            data = cache.get('findKey')
            
        return render(request, template_name, data)

#키워드 검색
def runCehck(request):
    template_name = 'checklowprice/checklowprice.html'
    data = request.POST.get('search1')
    
    cache_key = 'findKey'
    count = cache.get(cache_key, None)

    data = naverShopSearch.getlowprice(data)
    cache.set('findKey', data) 
    
    return render(request, template_name, data)


