from bs4 import BeautifulSoup
import requests   
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import os
from selenium.webdriver.support.wait import WebDriverWait
import time
from openpyxl import load_workbook

SUJIN_BASE_URL = 'http://www.sujinpet.co.kr'

path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'chromedriver')

driver = ""
#jsonFile작성
def makeProductJson(productName, sellPrice, buyPrice, urllink):
    if  urllink == "":
        urllink = "#"
    else: 
        urllink = SUJIN_BASE_URL + urllink
    
    proDetail = {
                    "productName": productName,
                    "sellPrice": sellPrice,
                    "buyPrice": buyPrice, 
                    "link": urllink,
                }
    
    return proDetail
    
#soup작성
def getSoup(pageLink):
    #pageLink = codecs.open("C:/Users/mita/eclipse-workspace/keySearch/findKey/templates/findKey/crawlSujiPet.html", 'r', 'utf-8')
    soup = BeautifulSoup(pageLink, 'html.parser')
    return soup

def makeExcel(productName, conturyName, option_NameList, option_PriceList, detailInfo):
    
    xlsxFile = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'sujinExcel.xlsx')
    
    # 新規ワークブックを作る --- (*2)
    wb = load_workbook(filename=xlsxFile)
    ws = wb.get_sheet_by_name('Sheet1')
    
    x = 1
    for j in range(1, 1000):
        if ws.cell(column=1, row=j)._value is None:
            x = j
            break

    ws.cell(column=1, row=x, value="트랜드49 " + productName)
    ws.cell(column=2, row=x, value=conturyName)
    ws.cell(column=3, row=x, value=option_NameList)
    ws.cell(column=4, row=x, value=option_PriceList)
    ws.cell(column=5, row=x, value="'" + str(detailInfo))
    wb.save(xlsxFile)
    

def getDetail(productName, rulLink):
    global driver
    
    driver.get(SUJIN_BASE_URL + rulLink)
    input_element = driver.page_source.encode('utf-8')
    soup = BeautifulSoup(input_element, 'html.parser')
    
    conturyName = ""
    
    #makeCom
    contryFLg = False
    makeConturyList = soup.find('div', class_='table-opt')
    makeContury = makeConturyList.findAll("div", class_ = 'tb-left')
    for contury in makeContury:
        if contury.string == '원산지':
            contryFLg = True
            continue
        if contryFLg:
            conturyName = contury.string.replace(' ', '', 120)
            break
    
    #getOption
    optionData = makeConturyList.find(id='MK_p_s_0').find_all("option")
    option_PriceList = ""
    option_NameList = ""
    i = 0
    for option in optionData:
        if i != 0:
            value = option['opt_title']
            option_NameList = option_NameList + "," +value
            
            if len(option['price'].split(',')) > i:
                value = option['price'].split(',')[i - 1]
                option_PriceList = option_PriceList + "," +value
        i = i + 1
    
    #상세페이지 정보
    detailInfo = soup.find('div', class_='prd-detail').find('div', class_='cboth pdt20 center')
    
    #엑셀 작성
    makeExcel(productName, conturyName, option_NameList, option_PriceList, detailInfo)
    driver.implicitly_wait(1)
    
def getPorductList(pageLink, jsonProDetail):
    global driver 
    driver.get(SUJIN_BASE_URL + pageLink)
    driver.implicitly_wait(2)
    html = driver.page_source
    soup = getSoup(html)
    productList = soup.findAll("ul", class_="info")
    
    for pro in productList:
        proName = pro.find("li", class_="dsc").text
    
        soldOutFlg = pro.find("li", class_="consumer")
        if soldOutFlg is None:
            sellPrice = "품절"
            buyPrice  = "-"
            rulLink   = ""
        else:
            sellPrice = pro.find("li", class_="consumer").text
            buyPrice  = pro.find("li", class_="price").text
            rulLink   = pro.find("li", class_="dsc").find('a')['href']

        #엑셀 출력
        if rulLink != "":
            getDetail(proName, rulLink)
        
        #jsoin파일 작성
        proDetail = makeProductJson(proName, sellPrice, buyPrice, rulLink)

        data = [proDetail]
        jsonProDetail.extend(data)
        
    return jsonProDetail

#검색 시작
def getCheckSujinPet():
    global driver 
    
    driver = webdriver.Chrome(path)
    #로그인
    uri  = 'http://www.sujinpet.co.kr/shop/member.html?type=login'
    driver.get(uri)
    time.sleep(3)
    driver.find_element_by_name('id').send_keys('imeun09')
    driver.find_element_by_name('passwd').send_keys('im2041403!!')
    time.sleep(3)
    driver.find_element_by_name('passwd').send_keys(Keys.ENTER)
    
    #상품검색
    proDuctUrlList = {
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=249516&xcode=021&mcode=007&scode=002&type=X&sort=order&cur_code=021007&GfDT=bmp7W1w%3D",
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=249515&xcode=021&mcode=007&scode=002&type=X&sort=order&cur_code=021007&GfDT=bmp1W10%3D",
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=249514&xcode=021&mcode=007&scode=002&type=X&sort=order&cur_code=021007&GfDT=bm1%2BW14%3D",
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=249513&xcode=021&mcode=007&scode=002&type=X&sort=order&cur_code=021007&GfDT=Zmd3Ug%3D%3D",
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=249512&xcode=021&mcode=007&scode=002&type=X&sort=order&cur_code=021007&GfDT=bmp8W1g%3D",
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=249511&xcode=021&mcode=007&scode=002&type=X&sort=order&cur_code=021007&GfDT=bmp%2FW1k%3D",
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=249510&xcode=021&mcode=007&scode=002&type=X&sort=order&cur_code=021007&GfDT=bmp3Vw%3D%3D",
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=249509&xcode=021&mcode=007&scode=002&type=X&sort=order&cur_code=021007&GfDT=Z2p3Vg%3D%3D",
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=231938&xcode=021&mcode=007&scode=004&type=X&sort=order&cur_code=021007&GfDT=amh3Ul8%3D",
        "http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=246822&xcode=029&mcode=012&scode=&type=X&sort=order&cur_code=029&GfDT=bGh3VFk%3D",
        }
    
    soldOutList = {
                    "sujinPetSoldOutList": "",
                }

    soldOut = {}
    time.sleep(3)
    for proDuctUrl in proDuctUrlList:
        driver.get(proDuctUrl)
        time.sleep(3)
        html = driver.page_source
        soup = getSoup(html)
        stateName = soup.find("div", class_="cboth prd-btns")
        
        if stateName.text == "품절" or stateName.text == "일시품절":
            soldOut.append(soup.find("div", class_="cboth tit-prd"))
            soldOut.append(proDuctUrl)
           
    soldOutList["sujinPetSoldOutList"] = soldOutList
     
    return soldOutList
    

def getCheckBananaB2b():

    global driver 
    driver = webdriver.Chrome(path)
    #로그인
    uri  = 'http://bananab2b.com/member/login.html'
    driver.get(uri)
    driver.implicitly_wait(3)
    driver.find_element_by_name('member_id').send_keys('imeun09')
    driver.find_element_by_name('member_passwd').send_keys('im2041403!!')
    time.sleep(3)
    driver.find_element_by_name('member_passwd').send_keys(Keys.ENTER)
    
    time.sleep(3)
    driver.get("http://bananab2b.com/myshop/wish_list.html")
    time.sleep(2)
    html = driver.page_source
    soup = getSoup(html)
    stateName = soup.find("div", class_="cboth prd-btns")
    
#카테고리검색 시작        
def getChekcProduct():
    global driver
    time.sleep(5)
    shopName = "BANANA_B2B"
    #로그인
    if shopName == "SUJINPET":
       soldOutList = getCheckSujinPet()
        
    
    elif shopName == "BANANA_B2B":
       soldOutList = getCheckBananaB2b()
    
    return soldOutList




#파일 오픈 방법
# url = 'http://test.com/api/image/'
# file = {'upload_file': open('test.png', 'rb')}
# res = requests.post(url, files=file)

# for row in get_cells:
#     for cell in row:
#         #getKeywords(cell.value)
#         #keyWords = cell.value.replace(" ",",")
#         keyWords = cell.value.split(" ")
#         time.sleep(1)
#         for keyWord in keyWords:
#             if keyWord == "":
#                 exit
#             getKeywords(keyWord)
