from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import time
from selenium.webdriver import Chrome, ChromeOptions
import openpyxl as excel
import chromedriver_binary
from openpyxl import load_workbook
import os
from asyncore import write

# ブラウザーを起動
# options = Options()
# options.add_argument('--headless')
# driver = webdriver.Chrome('chromedriver.exe', chrome_options=options)

xlsxFile = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'sujinExcel.xlsx')
# 新規ワークブックを作る --- (*2)
wb = load_workbook(filename=xlsxFile)
ws = wb.get_sheet_by_name('Sheet1')

for i in range(1, 10):
    for j in range(1, 10):
        v = i * j
        ws.cell(column=68, row=2, value="test") # --- (*1)


wb.save("sujinExcel.xlsx")



options = ChromeOptions()
# options.add_argument("--headless")

driver = webdriver.Chrome(options=options)

# download_path="./download"
# driver.command_executor._commands["send_command"] = ("POST", '/')
# driver.execute("send_command", {
#     'cmd': 'Page.setDownloadBehavior',
#     'params': {
#         'behavior': 'allow',
#         # ダウンロード先
#         'downloadPath': download_path
#     }
# })
# Google検索画面にアクセス
driver.get('http://www.sujinpet.co.kr/shop/member.html?type=login')
input_element = driver.page_source

time.sleep(5)
# (a) 検索ボックスを選択
input_element = driver.find_element_by_name("id")
input_element.send_keys("imeun09")
input_element = driver.find_element_by_name("passwd")
input_element.send_keys("im2041403!!")
input_element.send_keys(Keys.ENTER)
# 
time.sleep(4)
PATH = 'http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=192719&xcode=020&mcode=008&scode=001&type=X&sort=order&cur_code=020008&GfDT=aGV9'
driver.get('http://www.sujinpet.co.kr/shop/shopdetail.html?branduid=192719&xcode=020&mcode=008&scode=001&type=X&sort=order&cur_code=020008&GfDT=aGV9')
input_element = driver.page_source.encode('utf-8')
# driver.find_element_by_class_name("prd-detail")

soup = BeautifulSoup(input_element, 'html.parser')

#makeCom
contryFLg = False
makeConturyList = soup.find('div', class_='table-opt')
makeContury = makeConturyList.find_all("div", class_ = 'tb-left')
for contury in makeContury:
    if contury.string == '원산지':
        contryFLg = True
        continue
    if contryFLg:
        print(contury.string.replace(' ', '', 120))
        break

#getOption
optionData = makeConturyList.find(id='MK_p_s_0').find_all("option")
option_PriceList = []
option_NameList = []
i = 0
for option in optionData:
    if i != 0:
        value = option['opt_title']
        option_NameList.append(value)
        value = option['price'].split(',')[i - 1]
        option_PriceList.append(value)
    i = i + 1

print(option_PriceList)

#getDetail
data = soup.find('div', class_='prd-detail').find('div', class_='cboth pdt20 center')
data.find('div', class_='cboth pdt20 center')
driver.quit()
# ブラウザーを終了
