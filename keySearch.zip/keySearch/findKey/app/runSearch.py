import time
import random
import requests
from findKey.app import signaturehelper
from openpyxl import load_workbook
import json

#네이버 광고센터 접속
BASE_URL = 'https://api.naver.com'
API_KEY = '0100000000750d4716871fd4d6cd2498e3452cb3b0f1c706ecb4632b8543fcf43eb8333060'
SECRET_KEY = 'AQAAAAB1DUcWhx/U1s0kmONFLLOwNGU51Ib3D0EgU9Iq2798ZQ=='
CUSTOMER_ID = '1863222'

# writeFileName = "C:/Users/mita/keywordSearch/search/excelFile/resultSearch.xlsx"
# writeExcel = load_workbook(writeFileName, data_only=True)
# load_wb = load_workbook("C:/Users/mita/keywordSearch/search/excelFile/SMARTSTORE_1.xlsx", data_only=True)
# i = 3

# #검색시트 이름으로 불러오기
# load_ws = load_wb['Sheet1']
# get_cells =  load_ws['C2':'C50']
# 
# #출력시트 불러오기
# write_ws = writeExcel['Sheet1']



#getNvaerHeader
def get_header(method, uri, api_key, secret_key, customer_id):
    timestamp = str(round(time.time() * 1000))
    signature = signaturehelper.Signature.generate(timestamp, method, uri, SECRET_KEY)
    return {'Content-Type': 'application/json; charset=UTF-8', 'X-Timestamp': timestamp, 'X-API-KEY': API_KEY, 'X-Customer': str(CUSTOMER_ID), 'X-Signature': signature}

#jsonParse
# def jsonParse(json_data):
#     #write_ws.active
#     #json읽기
#     #json_data = json.read(jsonValue)
#     #엑셀 출력
#     global i
# 
#     for author in json_data['keywordList']:
#         write_ws.cell(i,1,author["relKeyword"])
#         write_ws.cell(i,2,author["monthlyPcQcCnt"])
#         write_ws.cell(i,3,author["monthlyMobileQcCnt"])
#         write_ws.cell(i,4,author["monthlyAvePcClkCnt"])
#         write_ws.cell(i,5,author["monthlyAveMobileClkCnt"])
#         write_ws.cell(i,6,author["monthlyAvePcCtr"])
#         write_ws.cell(i,6,author["monthlyAveMobileCtr"])
#         write_ws.cell(i,6,author["plAvgDepth"])
#         # + "["+ author["compIdx"] + "]"
#         i = i + 1
#     rowCount = i
#     writeExcel.save(writeFileName)
#getKeyword
def getKeywords(keyWord):
    uri = '/keywordstool'
    method = 'GET'
    r = requests.get(BASE_URL + uri, params={'hintKeywords': keyWord, 'showDetail':"1"}, headers=get_header(method, uri, API_KEY, SECRET_KEY, CUSTOMER_ID))
    return r.json()

# for row in get_cells:
#     for cell in row:
#         #getKeywords(cell.value)
#         #keyWords = cell.value.replace(" ",",")
#         keyWords = cell.value.split(" ")
#         time.sleep(1)
#         for keyWord in keyWords:
#             if keyWord == "":
#                 exit
#             getKeywords(keyWord)
