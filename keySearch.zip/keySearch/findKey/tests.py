from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import requests   
import urllib
from itertools import product
import codecs
import json
from collections import OrderedDict

#jsonFile작성
def makeProductJson(productName, sellPrice, buyPrice, urllink):
    proDetail = {"productName": productName, "sellPrice": sellPrice,"buyPrice": buyPrice,"link": urllink}
    return proDetail
    
#soup작성
def getSoup(pageLink):
    pageLink = codecs.open("C:/Users/mita/eclipse-workspace/keySearch/findKey/templates/findKey/crawlSujiPet.html", 'r', 'utf-8')
    soup = BeautifulSoup(pageLink, 'html.parser')
    return soup

def getPorductList(pageLink, jsonData):
    soup = getSoup(pageLink)
    productList = soup.findAll("ul", class_="info")
    
    for pro in productList:
        proName = pro.find("li", class_="dsc").text
    
        soldOutFlg = pro.find("li", class_="consumer")
        if soldOutFlg is None:
            sellPrice = "품절"
            buyPrice  = "-"
            rulLink   = "-"
        else:
            sellPrice = pro.find("li", class_="consumer").text
            buyPrice  = pro.find("li", class_="price").text
            rulLink   = pro.find("li", class_="dsc").find('a')['href']

        proDetail = makeProductJson(proName, sellPrice, buyPrice, rulLink)

        data = [proDetail]
        jsonData.extend(data)
        
    return jsonProDetail
        
BASE_URL = 'http://www.sujinpet.co.kr/'
response = requests.get('http://www.sujinpet.co.kr/shop/member.html?type=login')
response.encoding='euc-kr'  # 한글 인코
soup = BeautifulSoup(response.text, 'html.parser')
kategoris = soup.find("div", class_="left_menu_absolute")

kategori1 = kategoris.find_all("li", class_="left_sub_title")
kategori2 = kategoris.find_all("ul", class_="left_sub_cate")

jsonProDetail = {
      "productName": "상품명",
      "sellPrice": "소매가격",
      "buyPrice": "도매가격",
      "link": "링크",
    }

jsonKategori = {
      "kategori1": "KATEGORI_BIG",
      "kategori2": "KATEGORI_SMALL",
      "productDetail": jsonProDetail,
      "kategoriLink1": "KATEGORI_LINK1",
      "kategoriLink2": "KATEGORI_LINK2",
    }

jsonData = jsonKategori.get("productDetail")

for n in kategori1:
    rulLink = n.find('a')['href']
    text = n.text.strip()
    if text == "미용/목욕용품" :
        print(rulLink)
        break

for n in kategori2:
    texts = n.findAll('li')
    rulLink = n.find('a')['href']
    for text in texts:
        if text.get_text() == "하림" :
            rulLink = text.find('a')['href']
            print(rulLink)
            break

#1페이지 실행

#2페이지 이후 루프로 실행
soup = getSoup("pageLink")
productList = soup.findAll("ul", class_="info")
pageList = soup.select("ol.paging li")

for page in pageList:
    pagelink = page.find("a")
    if pagelink.text != "1" and pagelink.text.isdigit():
        jsonData = getPorductList(pagelink['href'], [jsonData])

dictData = {"sujipetList": [] }
dictData["sujipetList"] = [jsonData]

print(dictData)
#파일 오픈 방법
# url = 'http://test.com/api/image/'
# file = {'upload_file': open('test.png', 'rb')}
# res = requests.post(url, files=file)

# for row in get_cells:
#     for cell in row:
#         #getKeywords(cell.value)
#         #keyWords = cell.value.replace(" ",",")
#         keyWords = cell.value.split(" ")
#         time.sleep(1)
#         for keyWord in keyWords:
#             if keyWord == "":
#                 exit
#             getKeywords(keyWord)
