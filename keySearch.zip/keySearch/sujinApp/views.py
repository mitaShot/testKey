from django.shortcuts import render
from sujinApp.app import getPoductList
from django.views import generic

#수지펫검색
def runSearchSujiPet(request):
    template_name = 'sujinApp/crawlSujiPet.html'
    
    data = request.POST.get('kategori2')
    #카테고리 검색
    data = getPoductList.getKeywords(data)
    return render(request, template_name, data)


class CrawlSujiPet(generic.TemplateView):
    def get(self, request, *args, **kwargs):
        template_name = 'sujinApp/crawlSujiPet.html'
        return render(request, template_name)
