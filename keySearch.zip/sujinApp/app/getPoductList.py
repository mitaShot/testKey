from bs4 import BeautifulSoup
import requests   
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import os
from selenium.webdriver.support.wait import WebDriverWait
import time
from openpyxl import load_workbook

BASE_URL = 'http://www.sujinpet.co.kr'
path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'chromedriver')

driver = ""
#jsonFile작성
def makeProductJson(productName, sellPrice, buyPrice, urllink):
    if  urllink == "":
        urllink = "#"
    else: 
        urllink = BASE_URL + urllink
    
    proDetail = {
                    "productName": productName,
                    "sellPrice": sellPrice,
                    "buyPrice": buyPrice, 
                    "link": urllink,
                }
    
    return proDetail
    
#soup작성
def getSoup(pageLink):
    #pageLink = codecs.open("C:/Users/mita/eclipse-workspace/keySearch/findKey/templates/findKey/crawlSujiPet.html", 'r', 'utf-8')
    soup = BeautifulSoup(pageLink, 'html.parser')
    return soup

def makeExcel(productName, conturyName, option_NameList, option_PriceList, detailInfo):
    
    xlsxFile = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'sujinExcel.xlsx')
    
    # 新規ワークブックを作る --- (*2)
    wb = load_workbook(filename=xlsxFile)
    ws = wb.get_sheet_by_name('Sheet1')
    
    x = 1
    for j in range(1, 1000):
        if ws.cell(column=1, row=j)._value is None:
            x = j
            break

    ws.cell(column=1, row=x, value="트랜드49 " + productName)
    ws.cell(column=2, row=x, value=conturyName)
    ws.cell(column=3, row=x, value=option_NameList)
    ws.cell(column=4, row=x, value=option_PriceList)
    ws.cell(column=5, row=x, value="'" + str(detailInfo))
    wb.save(xlsxFile)
    

def getDetail(productName, rulLink):
    global driver
    
    driver.get(BASE_URL + rulLink)
    input_element = driver.page_source.encode('utf-8')
    soup = BeautifulSoup(input_element, 'html.parser')
    
    conturyName = ""
    
    #makeCom
    contryFLg = False
    makeConturyList = soup.find('div', class_='table-opt')
    makeContury = makeConturyList.findAll("div", class_ = 'tb-left')
    for contury in makeContury:
        if contury.string == '원산지':
            contryFLg = True
            continue
        if contryFLg:
            conturyName = contury.string.replace(' ', '', 120)
            break
    
    #getOption
    optionData = makeConturyList.find(id='MK_p_s_0').find_all("option")
    option_PriceList = ""
    option_NameList = ""
    i = 0
    for option in optionData:
        if i != 0:
            value = option['opt_title']
            option_NameList = option_NameList + "," +value
            
            if len(option['price'].split(',')) > i:
                value = option['price'].split(',')[i - 1]
                option_PriceList = option_PriceList + "," +value
        i = i + 1
    
    #상세페이지 정보
    detailInfo = soup.find('div', class_='prd-detail').find('div', class_='cboth pdt20 center')
    
    #엑셀 작성
    makeExcel(productName, conturyName, option_NameList, option_PriceList, detailInfo)
    driver.implicitly_wait(1)
    
def getPorductList(pageLink, jsonProDetail):
    global driver 
    driver.get(BASE_URL + pageLink)
    driver.implicitly_wait(2)
    html = driver.page_source
    soup = getSoup(html)
    productList = soup.findAll("ul", class_="info")
    
    for pro in productList:
        proName = pro.find("li", class_="dsc").text
    
        soldOutFlg = pro.find("li", class_="consumer")
        if soldOutFlg is None:
            sellPrice = "품절"
            buyPrice  = "-"
            rulLink   = ""
        else:
            sellPrice = pro.find("li", class_="consumer").text
            buyPrice  = pro.find("li", class_="price").text
            rulLink   = pro.find("li", class_="dsc").find('a')['href']

        #엑셀 출력
        if rulLink != "":
            getDetail(proName, rulLink)
        
        #jsoin파일 작성
        proDetail = makeProductJson(proName, sellPrice, buyPrice, rulLink)

        data = [proDetail]
        jsonProDetail.extend(data)
        
    return jsonProDetail

#검색 시작
def getKeywords(kategoriName2):
    global driver 
    
    driver = webdriver.Chrome(path)
    #로그인
    uri  = 'http://www.sujinpet.co.kr/shop/member.html?type=login'
    driver.get(uri)
    driver.implicitly_wait(3)
    driver.find_element_by_name('id').send_keys('imeun09')
    driver.find_element_by_name('passwd').send_keys('im2041403!!')
    time.sleep(4)
    driver.find_element_by_name('passwd').send_keys(Keys.ENTER)

#     driver.find_element_by_xpath("//form[@class='btn-mlog']/button").send_keys(Keys.ENTER)
#     kategori1 = "강아지사료/분유"
#     kategori2 = "사이언스"
#     html = driver.page_source
#     soup = BeautifulSoup(html, 'html.parser')
#     kategoris = soup.find("div", class_="left_menu_absolute")

    #카테고리 검색 시작
    jsonData = getPoductList(kategoriName2)
    return jsonData
    

#카테고리검색 시작        
def getPoductList(kategoriName2):
    global driver
    time.sleep(5)
    #로그인
    response = requests.get('http://www.sujinpet.co.kr/shop/member.html?type=login')
    response.encoding='euc-kr'  # 한글 인코
    soup = BeautifulSoup(response.text, 'html.parser')
    kategoris = soup.find("div", class_="left_menu_absolute")

    kategori1 = kategoris.find_all("li", class_="left_sub_title")
    kategori2 = kategoris.find_all("ul", class_="left_sub_cate")
    
    jsonProDetail = {
        }
    
    jsonKategori = {
          "kategori1": "KATEGORI_BIG",
          "kategori2": kategoriName2,
          "productDetail": jsonProDetail,
          "kategoriLink1": "KATEGORI_LINK1",
          "kategoriLink2": "KATEGORI_LINK2",
        }
    #json작석
    jsonData = jsonKategori.get("productDetail")
    
#     for n in kategori1:
#         rulLink = n.find('a')['href']
#         text = n.text.strip()
#         if text == "미용/목욕용품" :
#             print(rulLink)
#             break
    
    for n in kategori2:
        texts = n.findAll('li')
#         rulLink = n.find('a')['href']
        for text in texts:
            if text.get_text() == kategoriName2:
                rulLink = text.find('a')['href']
                break
    
    #해당 카테고리 이동    
    WebDriverWait(driver, 3)
    driver.get(BASE_URL + rulLink)
    html = driver.page_source
    WebDriverWait(driver, 3)
    soup = getSoup(html)
    
    #2페이지 이후 루프로 실행
    pageList = soup.select("ol.paging li")
    
    jsonData = []
    for page in pageList:
        pagelink = page.find("a")
        if pagelink.text != "" and pagelink.text.isdigit():
            jsonData.extend(getPorductList(pagelink['href'], [jsonData]))
            driver.implicitly_wait(1)
    
    dictData = {"sujipetList": [] }
    dictData["sujipetList"] = jsonData
    
    return dictData




#파일 오픈 방법
# url = 'http://test.com/api/image/'
# file = {'upload_file': open('test.png', 'rb')}
# res = requests.post(url, files=file)

# for row in get_cells:
#     for cell in row:
#         #getKeywords(cell.value)
#         #keyWords = cell.value.replace(" ",",")
#         keyWords = cell.value.split(" ")
#         time.sleep(1)
#         for keyWord in keyWords:
#             if keyWord == "":
#                 exit
#             getKeywords(keyWord)
