from django.apps import AppConfig


class SujinappConfig(AppConfig):
    name = 'sujinApp'
